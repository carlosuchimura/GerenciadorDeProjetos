const Home = () => {
  return (
    <div>
      <h1>Bem-vindo à Página de Projetos</h1>
    </div>
  );
}

export default Home;