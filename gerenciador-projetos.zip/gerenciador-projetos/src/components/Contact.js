const Contact = () => {
  return (
    <div>
    <h1>Entre em contato</h1>
    <p><a href="mailto:chimura@gmail.com">chimura@gmail.com</a></p>
  </div>
);
}

export default Contact;;